<?php
include('login.php');
if(isset($_SESSION['login_user_sys'])){
	$_SESSION['login_user_sys']=$username;
	$sql = "select tipo from usuarios WHERE email = '" . $username . "';";
		$Result=mysqli_query($con, $sql);
		while($row=$Result->fetch_array()) {
           $tipo=$row["tipo"];
		}
		if($tipo!=2){
			header("location: profile.php");
		}
		if($tipo==2){
			header("location: profile2.php");
		}
}
?>
<!DOCTYPE HTML>
<html>
<head>
<title>XTHEATER</title>
<head>

  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
	<link rel="stylesheet" href="css/login.css">
  <link rel="stylesheet" href="css/cabecera.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.0.0/animate.min.css">
  <link rel="stylesheet"  href="style.css">
  <link rel="stylesheet" href="home.css">

  <link rel="icon" type="image/png" href="imagenes/logos/caras.png">
  <title>Iniciar sesión</title>
  </head>
</head>

<body>



<div class="header agile">
	<div class="wrap">
		<div class="login-main wthree">
			<div class="login">
				<section class="form-register">
					<center>
				      <h4>Iniciar sesión</h4>
						</center>
			<form action="#" method="post">
				<input  class="controls" type="text" placeholder="Correo electrónico" required="" name="username" required>
				<input class="controls" type="password" placeholder="Contraseña" name="password" required>
			<input   name="submit" type="submit" value="Ingresar">

			</form>
			<div class="clear"> </div>
				<span><?php echo $error; ?></span>
			</div>
		</div>
	</div>
</div>
</section>
</body>
</html>
