<?php
include('session.php');
if($tipo==1){header("location: profile.php");}
?><!doctype html>
<html>

<head>

	<meta charset="UTF-8">
              <meta name="viewport" content="width=device-width, initial-scale=1.0">
              <meta http-equiv="X-UA-Compatible" content="ie=edge">
              <link rel="stylesheet" href="home.css">
              <link rel="stylesheet" href="test.css">
							<link rel="stylesheet" href="tabla.css">



              <link rel="icon" type="image/png" href="imagenes/logos/caras.png">


<title>Venta</title>
</head>

<body>

	<header>
	            <div class="izq">

	                <div class="img">
	                    <img src="imagenes/logos/caras.png" alt="">
	                </div>
	                <div class="title">
	                    <h2>XTHEATER</h2>

	                </div>

	            </div>

	            <div class="der">

	                <div class="switch" id="switch">
	                    <img src="imagenes/logos/luna.png" alt="">
	                </div>

	                <a href="index.php">
	                    <div class="boton">
	                        <img src="imagenes/logos/cerrar.png" alt="">
	                        <p>CerrarSesión</p>
	                    </div>
	                </a>

	                <a href="RealizarVenta2.php">
	                    <div class="boton">
	                        <img src="imagenes/logos/regresar.png" alt="">
	                        <p>Regresar</p>
	                    </div>
	                </a>
	            </div>
	        </header>


					<table width="400" border="1">

				</table>
					<div class="sec1">
					<form action="boleto.php" method="post">

						<input type="text" name="idventa">
						<input type="submit">
					</form>

				<?php
					$idventa=$_POST['idventa'];

					$sql = "SELECT * FROM ventas WHERE idventa LIKE '%".$idventa."%';";
					$Result=mysqli_query($con,$sql);
					$Registros=mysqli_num_rows($Result);
							   if($Registros<=0)
								   {
									 echo "<div align='center'>";
									 echo "<h2>No se encontraron resultados</h2>";
									 echo "</div>";
							   		}else{
								   ?>
						   <table border=1>
							<thead><tr>
							<th width="300"><strong> ClaveVenta</strong></th>
					<th>	<strong> ClaveFuncion </strong></th>
					<th>	<strong> Asiento</strong></th>
						<th>	<strong> Precio </strong></th>
								</tr></thead><tbody>
							<?php
							while($row=$Result->fetch_array()) {
							   ?>
							   <tr>
									 <td> <?php printf($row["idventa"]); ?>   </td>
									 <td> <?php printf($row["idfuncion"]); ?>   </td>
									 <td> <?php printf($row["nombre"]); ?> </td>
									 <td> <?php printf($row["precio"]); ?> </td>
							   </tr>
							<?php }}?>
					</tbody></table>
					<center><h1>¡GRACIAS POR SU PREFERENCIA!</h1></center>
				</div>
        </body>
        <script src="test.js"></script>
        </html>
