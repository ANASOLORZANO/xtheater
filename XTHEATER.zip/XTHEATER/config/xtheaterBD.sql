-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 24-04-2020 a las 04:15:10
-- Versión del servidor: 10.4.6-MariaDB
-- Versión de PHP: 7.1.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `xtheater`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `asientos`
--

CREATE TABLE `asientos` (
  `asiento` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `asientos`
--

INSERT INTO `asientos` (`asiento`) VALUES
('a1'),
('b1'),
('c1'),
('d1');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `boleto`
--

CREATE TABLE `boleto` (
  `folio` int(10) NOT NULL,
  `funcion` int(10) NOT NULL,
  `idobra` int(10) NOT NULL,
  `idlugar` int(10) NOT NULL,
  `idvendedor` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `boleto`
--

INSERT INTO `boleto` (`folio`, `funcion`, `idobra`, `idlugar`, `idvendedor`) VALUES
(206737, 2, 1, 3, 1),
(249298, 2, 1, 2, 1),
(410823, 3, 1, 8, 1),
(546714, 2, 1, 1, 1),
(669781, 3, 1, 7, 1),
(712318, 3, 1, 6, 1),
(831329, 3, 1, 5, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `funcion`
--

CREATE TABLE `funcion` (
  `idfuncion` int(10) NOT NULL,
  `idobra` int(10) NOT NULL,
  `fecha` date NOT NULL,
  `hora` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `funcion`
--

INSERT INTO `funcion` (`idfuncion`, `idobra`, `fecha`, `hora`) VALUES
(2, 1, '2020-04-25', '18:00:00'),
(3, 1, '2020-04-26', '18:00:00');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `lugar`
--

CREATE TABLE `lugar` (
  `idlugar` int(10) NOT NULL,
  `asiento` varchar(5) NOT NULL,
  `idfuncion` int(10) NOT NULL,
  `precio` int(10) NOT NULL,
  `disponible` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `lugar`
--

INSERT INTO `lugar` (`idlugar`, `asiento`, `idfuncion`, `precio`, `disponible`) VALUES
(1, 'a1', 2, 1000, 'NO'),
(2, 'b1', 2, 800, 'NO'),
(3, 'c1', 2, 600, 'NO'),
(4, 'd1', 2, 400, 'SI'),
(5, 'a1', 3, 1000, 'NO'),
(6, 'b1', 3, 800, 'NO'),
(7, 'c1', 3, 600, 'NO'),
(8, 'd1', 3, 400, 'NO');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `obras`
--

CREATE TABLE `obras` (
  `idobra` int(10) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `clasificacion` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `obras`
--

INSERT INTO `obras` (`idobra`, `nombre`, `clasificacion`) VALUES
(1, 'Caperucita Roja', 'A');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(10) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `tipo` int(1) NOT NULL,
  `nombre` varchar(255) NOT NULL,
  `apellidos` varchar(255) NOT NULL,
  `fdn` date NOT NULL,
  `direccion` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id`, `email`, `password`, `tipo`, `nombre`, `apellidos`, `fdn`, `direccion`) VALUES
(1, 'user', '1234', 2, 'Pedro', 'Picapiedra', '1980-04-15', 'Av. Roca Dura'),
(2, 'admin', '1234', 1, 'Fernando', 'Jimenez', '1998-08-06', 'Rafael Delgado, Ver.');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `asientos`
--
ALTER TABLE `asientos`
  ADD PRIMARY KEY (`asiento`);

--
-- Indices de la tabla `boleto`
--
ALTER TABLE `boleto`
  ADD PRIMARY KEY (`folio`),
  ADD KEY `fk_fu` (`idvendedor`),
  ADD KEY `fk_funcion` (`funcion`),
  ADD KEY `fk_lugar` (`idlugar`),
  ADD KEY `fk_obra` (`idobra`);

--
-- Indices de la tabla `funcion`
--
ALTER TABLE `funcion`
  ADD PRIMARY KEY (`idfuncion`),
  ADD KEY `funcion_ibfk_1` (`idobra`);

--
-- Indices de la tabla `lugar`
--
ALTER TABLE `lugar`
  ADD PRIMARY KEY (`idlugar`),
  ADD KEY `lugar_ibfk_1` (`asiento`),
  ADD KEY `lugar_ibfk_2` (`idfuncion`);

--
-- Indices de la tabla `obras`
--
ALTER TABLE `obras`
  ADD PRIMARY KEY (`idobra`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `boleto`
--
ALTER TABLE `boleto`
  MODIFY `folio` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=831330;

--
-- AUTO_INCREMENT de la tabla `funcion`
--
ALTER TABLE `funcion`
  MODIFY `idfuncion` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `lugar`
--
ALTER TABLE `lugar`
  MODIFY `idlugar` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT de la tabla `obras`
--
ALTER TABLE `obras`
  MODIFY `idobra` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `boleto`
--
ALTER TABLE `boleto`
  ADD CONSTRAINT `fk_fu` FOREIGN KEY (`idvendedor`) REFERENCES `usuarios` (`id`),
  ADD CONSTRAINT `fk_funcion` FOREIGN KEY (`funcion`) REFERENCES `funcion` (`idfuncion`),
  ADD CONSTRAINT `fk_lugar` FOREIGN KEY (`idlugar`) REFERENCES `lugar` (`idlugar`),
  ADD CONSTRAINT `fk_obra` FOREIGN KEY (`idobra`) REFERENCES `obras` (`idobra`);

--
-- Filtros para la tabla `funcion`
--
ALTER TABLE `funcion`
  ADD CONSTRAINT `funcion_ibfk_1` FOREIGN KEY (`idobra`) REFERENCES `obras` (`idobra`);

--
-- Filtros para la tabla `lugar`
--
ALTER TABLE `lugar`
  ADD CONSTRAINT `lugar_ibfk_1` FOREIGN KEY (`asiento`) REFERENCES `asientos` (`asiento`),
  ADD CONSTRAINT `lugar_ibfk_2` FOREIGN KEY (`idfuncion`) REFERENCES `funcion` (`idfuncion`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
