
<?php
include('session.php');
if($tipo==1){header("location: profile.php");}
?><!doctype html>
<html>

<head>

	<meta charset="UTF-8">
              <meta name="viewport" content="width=device-width, initial-scale=1.0">
              <meta http-equiv="X-UA-Compatible" content="ie=edge">
              <link rel="stylesheet" href="home.css">
              <link rel="stylesheet" href="test.css">
							<link rel="stylesheet" href="tabla.css">
							<link rel="stylesheet" type="text/css" href="estilos.css">


              <link rel="icon" type="image/png" href="imagenes/logos/caras.png">


<title>Venta</title>
</head>

<body>

	<header>
	            <div class="izq">

	                <div class="img">
	                    <img src="imagenes/logos/caras.png" alt="">
	                </div>
	                <div class="title">
	                    <h2>XTHEATER</h2>

	                </div>

	            </div>

	            <div class="der">

	                <div class="switch" id="switch">
	                    <img src="imagenes/logos/luna.png" alt="">
	                </div>

	                <a href="index.php">
	                    <div class="boton">
	                        <img src="imagenes/logos/cerrar.png" alt="">
	                        <p>CerrarSesión</p>
	                    </div>
	                </a>

	                <a href="profile2.php">
	                    <div class="boton">
	                        <img src="imagenes/logos/regresar.png" alt="">
	                        <p>Regresar</p>
	                    </div>
	                </a>
	            </div>
	        </header>

						<div class="sec1">
					<?php
						$sql = "SELECT funcion.idfuncion, obras.nombre, funcion.hora, funcion.fecha FROM `funcion`,`obras` WHERE funcion.idobra=obras.idobra";
						$Result=mysqli_query($con,$sql);
						$Registros=mysqli_num_rows($Result);


								   if($Registros<=0)
									   {
										 echo "<div align='center'>";
										 echo "<h2>No se encontraron resultados</h2>";
										 echo "</div>";
								   		}else{?>
									   <table border=1>
								<thead><tr>
								<th width="300"><strong> Clave </strong></th>
								<th><strong> Obra </strong></th>
								<th><strong> Hora </strong></th>
									<th><strong> Fecha </strong></th>
									</tr></thead><tbody><?php
								while($row=$Result->fetch_array()) {
								   ?>
								   <tr>
										 <td> <?php printf($row["idfuncion"]); ?>   </td>
									   <td> <?php printf($row["nombre"]); ?>   </td>
									   <td> <?php printf($row["hora"]); ?> </td>
									   <td> <?php printf($row["fecha"]); ?> </td>
								   </tr>
								<?php }}?>
						</tbody></table>
					</div>


					<div class="sec2">

						<form method="post">
                 <h1>Asientos</h1>
								 <h1> 1B-10B:$750.00</h1>
								 <h1> 11B-20B:$650.00</h1>
								 <h1> 21B-30B:$850.00</h1>
									<input type="number" name="id" placeholder="Clave de la función ">
									<select name="lugar">
												   <option> Elige tu asiento</option>
												       <optgroup label="Asiento">
												       <option value="1">B1</option>
												       <option value="2">B2</option>
												       <option value="3">B3</option>
															 <option value="4">B4</option>
															 <option value="5">B5</option>
															 <option value="6">B6</option>
															 <option value="7">B7</option>
															 <option value="8">B8</option>
															 <option value="9">B9</option>
															 <option value="10">B10</option>
															 <option value="11">B11</option>
															 <option value="12">B12</option>
															 <option value="13">B13</option>
															 <option value="14">B14</option>
															 <option value="15">B15</option>
															 <option value="16">B16</option>
															 <option value="17">B17</option>
															 <option value="18">B18</option>
															 <option value="19">B19</option>
															 <option value="20">B20</option>
															 <option value="21">B21</option>
															 <option value="22">B22</option>
															 <option value="23">B23</option>
															 <option value="24">B24</option>
															 <option value="25">B25</option>
															 <option value="26">B26</option>
															 <option value="27">B27</option>
															 <option value="28">B28</option>
															 <option value="29">B29</option>
															 <option value="30">B30</option>

												   </optgroup>
												 </select>



                	<select name="precio">
									   <option> Precio </option>
									       <optgroup label="Precio">
													<option value="1">650</option>
									       <option value="2">750</option>
									       <option value="3">850</option>
											 </optgroup>
								</select>

									<input type="submit" name="añadir">


								</form>
								<?php
								 include("venta.php");
								 ?>
					</div>

					<div class="sec3">
					<form action="boleto.php" method="post">
					<h1> Ingrese la clave de la venta para imprimir boleto</h1>
					<input type="text" name="idventa">
					<input type="submit">
				  </form>

						<?php
							$sql = "SELECT * FROM ventas;";
							$Result=mysqli_query($con,$sql);
							$Registros=mysqli_num_rows($Result);


										 if($Registros<=0)
											 {
											 echo "<div align='center'>";
											 echo "<h2>No se encontraron resultados</h2>";
											 echo "</div>";
												}else{?>
											 <table border=1>
									<thead><tr>
									<th width="300"><strong> ClaveVenta</strong></th>
							<th>	<strong> ClaveFuncion </strong></th>
							<th>	<strong> Asiento</strong></th>
								<th>	<strong> Precio </strong></th>
									</th>
										</tr></thead><tbody><?php
									while($row=$Result->fetch_array()) {
										 ?>
										 <tr>
											 <td> <?php printf($row["idventa"]); ?>   </td>
											 <td> <?php printf($row["idfuncion"]); ?>   </td>
											 <td> <?php printf($row["nombre"]); ?> </td>
											 <td> <?php printf($row["precio"]); ?> </td>

										 </tr>
									<?php }}?>
							</tbody>
						</table>
						</div>
						<div class="sec3">
						</div>


					</div>



        </body>
        <script src="test.js"></script>
        </html>
