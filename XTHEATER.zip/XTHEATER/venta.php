<?php
include("con_db.php");

if (isset($_POST['añadir'])) {
    if ( strlen($_POST['id']) >= 1 && strlen($_POST['lugar']) >= 1&& strlen($_POST['precio']) >= 1) {

      $id = trim($_POST['id']);
	    $lugar = trim($_POST['lugar']);
      $precio = trim($_POST['precio']);


	    $consulta = "INSERT INTO ventas(idfuncion, nombre, precio) VALUES ('$id','$lugar','$precio')";
	    $resultado = mysqli_query($conex,$consulta);
	    if ($resultado) {
	    	?>
	    	<h3 class="ok">Añadido correctamente</h3>
           <?php

           

	    } else {
	    	?>
	    	<h3 class="bad">¡Ups ha ocurrido un error!</h3>
           <?php
	    }
    }   else {
	    	?>
	    	<h3 class="bad">¡Por favor complete los campos!</h3>
           <?php
    }
}
