document.querySelector('#switch').addEventListener('click', () => {
    document.body.classList.toggle('dark');

    if(document.body.classList.contains('dark')){
        localStorage.setItem('modoOscuro', 'true');
    }
    else{
        localStorage.setItem('modoOscuro', 'false');
    }
});

if(localStorage.getItem('modoOscuro') === 'true'){
    document.body.classList.add('dark');
}
else{
    document.body.classList.remove('dark');
}