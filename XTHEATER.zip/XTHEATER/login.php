<?php
session_start();
$error='';
if (isset($_POST['submit'])) {
if (empty($_POST['username']) || empty($_POST['password'])) {
$error = "Username or Password is invalid";
}
else
{
$username=$_POST['username'];
$password=$_POST['password'];
// Estableciendo la conexion a la base de datos
include("config/db.php");//Contienen las variables, el servidor, usuario, contraseña y nombre  de la base de datos
include("config/conexion.php");//Contiene de conexion a la base de datos


$sql = "SELECT email, password FROM usuarios WHERE email = '" . $username . "' and password='".$password."';";
$query=mysqli_query($con,$sql);
$counter=mysqli_num_rows($query);
if ($counter==1){
		$_SESSION['login_user_sys']=$username;
    		$sql = "select tipo from usuarios WHERE email = '" . $username . "' and password='".$password."';";
		$Result=mysqli_query($con,$sql);
		while($row=$Result->fetch_array()) {
           $tipo=$row["tipo"];
		}
		if($tipo==1){
			header("location: profile.php"); // Redireccionando a la pagina profile.php
		}
		if($tipo==2){
			header("location: profile2.php"); // Redireccionando a la pagina profile.php
		}

} else {
$error = "El usuario o la contraseña es inválida.";
}
}
}
?>
