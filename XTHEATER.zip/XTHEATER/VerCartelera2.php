<?php
include('session.php');
if($tipo==1){header("location: profile.php");}
?><!doctype html>
<html>

<head>

	<meta charset="UTF-8">
              <meta name="viewport" content="width=device-width, initial-scale=1.0">
              <meta http-equiv="X-UA-Compatible" content="ie=edge">
              <link rel="stylesheet" href="home.css">
              <link rel="stylesheet" href="test.css">
							<link rel="stylesheet" href="tabla.css">

              <link rel="icon" type="image/png" href="imagenes/logos/caras.png">


<title>Cartelera</title>

</head>
<body>
	<header>
	            <div class="izq">

	                <div class="img">
	                    <img src="imagenes/logos/caras.png" alt="">
	                </div>
	                <div class="title">
	                    <h2>XTHEATER</h2>

	                </div>

	            </div>

	            <div class="der">

	                <div class="switch" id="switch">
	                    <img src="imagenes/logos/luna.png" alt="">
	                </div>

	                <a href="index.php">
	                    <div class="boton">
	                        <img src="imagenes/logos/cerrar.png" alt="">
	                        <p>CerrarSesión</p>
	                    </div>
	                </a>

	                <a href="RealizarVenta2.php">
	                    <div class="boton">
	                        <img src="imagenes/logos/venta.png" alt="">
	                        <p>RealizarVenta</p>
	                    </div>
	                </a>

	                <a href="BuscarObra2.php">
	                    <div class="boton">
	                        <img src="imagenes/logos/buscar.png" alt="">
	                        <p>BuscarObra</p>
	                    </div>
	                </a>

									<a href="profile2.php">
										 <div class="boton">
												 <img src="imagenes/logos/home.png" alt="">
												 <p>Inicio</p>
										 </div>
								 </a>

	            </div>

	        </header>


<center>
	<div class="sec1">
<?php
	$sql = "SELECT  obras.nombre, funcion.hora, funcion.fecha FROM `funcion`,`obras` WHERE funcion.idobra=obras.idobra";
	$Result=mysqli_query($con,$sql);
	$Registros=mysqli_num_rows($Result);


			   if($Registros<=0)
				   {
					 echo "<div align='center'>";
					 echo "<h2>No se encontraron resultados</h2>";
					 echo "</div>";
			   		}else{?>
				   <table border=1>
			<thead><tr>
			<th width="300"><strong> Obra </strong></th>
			<th><strong> Hora </strong></th>
				<th><strong> Fecha </strong></th>
				</tr></thead><tbody><?php
			while($row=$Result->fetch_array()) {
			   ?>
			   <tr>

				   <td> <?php printf($row["nombre"]); ?>   </td>
				   <td> <?php printf($row["hora"]); ?> </td>
				   <td> <?php printf($row["fecha"]); ?> </td>
			   </tr>
			<?php }}?>
	</tbody></table>

</div>
</center>
</body>
<script src="test.js"></script>
</html>
