<?php
include("con_db.php");

if (isset($_POST['añadir'])) {
    if (strlen($_POST['name']) >= 1 && strlen($_POST['dia']) >= 1 && strlen($_POST['hr']) >= 1) {
	    $name = trim($_POST['name']);
	    $dia = trim($_POST['dia']);
      $hr = trim($_POST['hr']);
	    $consulta = "INSERT INTO funcion(idobra, fecha, hora) VALUES ('$name','$dia','$hr')";
	    $resultado = mysqli_query($conex,$consulta);
	    if ($resultado) {
	    	?>
	    	<h3 class="ok">Función añadida</h3>
           <?php
	    } else {
	    	?>
	    	<h3 class="bad">¡Ups ha ocurrido un error!</h3>
           <?php
	    }
    }   else {
	    	?>
	    	<h3 class="bad">¡Por favor complete los campos!</h3>
           <?php
    }
}

?>
