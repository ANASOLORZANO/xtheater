<?php
include('session.php');
if($tipo==2){header("location: profile2.php");}
?>
<!doctype html>
<html>
	<head>

		<meta charset="UTF-8">
	              <meta name="viewport" content="width=device-width, initial-scale=1.0">
	              <meta http-equiv="X-UA-Compatible" content="ie=edge">
	              <link rel="stylesheet" href="home.css">
	              <link rel="stylesheet" href="test.css">
								<link rel="stylesheet" href="tabla.css">
								<link rel="stylesheet" type="text/css" href="estilos.css">
	              <link rel="icon" type="image/png" href="imagenes/logos/caras.png">

<title>Añadir</title>
</head>

<body>


		<header>
								<div class="izq">

										<div class="img">
												<img src="imagenes/logos/caras.png" alt="">
										</div>
										<div class="title">
												<h2>XTHEATER</h2>

										</div>

								</div>

								<div class="der">

										<div class="switch" id="switch">
												<img src="imagenes/logos/luna.png" alt="">
										</div>

										<a href="index.php">
											 <div class="boton">
													 <img src="imagenes/logos/cerrar.png" alt="">
													 <p>Salir</p>
											 </div>
									 </a>

									 <a href="VerFunciones.php">
	 										<div class="boton">
	 												<img src="imagenes/logos/cartelera.png" alt="">
	 												<p>Funciones</p>
	 										</div>
	 								</a>

										<a href="VerObras.php">
												<div class="boton">
														<img src="imagenes/logos/obras.png" alt="">
														<p>Obras</p>
												</div>
										</a>

										<a href="profile.php">
											 <div class="boton">
													 <img src="imagenes/logos/home.png" alt="">
													 <p>Inicio</p>
											 </div>
									 </a>

								</div>

						</header>
<div class="sec1">
	<form method="post">
				<h1>Añadir Empleado</h1>
				<input type="text" name="name" placeholder="Nombre ">
				<input type="text" name="app" placeholder="Apellido Paterno">
				<input type="text" name="apm" placeholder="Apellido Materno">
				<input type="text" name="sex" placeholder="Sexo">
				<input type="text" name="tel" placeholder="Telefono">
				<input type="submit" name="añadir">
			</form>
			<?php
			 include("añadirEmpleado.php");
			 ?>
</div>

						<div class="sec2">

						<?php
							$sql = "SELECT * FROM empleado;";
							$Result=mysqli_query($con,$sql);
							$Registros=mysqli_num_rows($Result);


									   if($Registros<=0)
										   {
											 echo "<div align='center'>";
											 echo "<h2>No se encontraron resultados</h2>";
											 echo "</div>";
									   		}else{?>
										   <table border=1>
									<thead><tr>
									<th width="300"><strong> Nombre </strong></th>
							<th>	<strong> Apellido paterno </strong></th>
							<th>	<strong> Apellido materno </strong></th>
								<th>	<strong> Sexo </strong></th>
								<th>		<strong> Telefono </strong></th>
									</th>
										</tr></thead><tbody><?php
									while($row=$Result->fetch_array()) {
									   ?>
									   <tr>
											 <td> <?php printf($row["nombre"]); ?>   </td>
										   <td> <?php printf($row["apaterno"]); ?>   </td>
										   <td> <?php printf($row["amaterno"]); ?> </td>
											 <td> <?php printf($row["sexo"]); ?> </td>
											 <td> <?php printf($row["telefono"]); ?> </td>
									   </tr>
									<?php }}?>
							</tbody>
						</table>
						</div>
						<div class="sec3">
						</div>


</body>
<script src="test.js"></script>
</html>
