<?php
include("con_db.php");

if (isset($_POST['añadir'])) {
    if ( strlen($_POST['name']) >= 1 && strlen($_POST['clas']) >= 1) {

      $name = trim($_POST['name']);
	    $clas = trim($_POST['clas']);

	    $consulta = "INSERT INTO obras(nombre, clasificacion) VALUES ('$name','$clas')";
	    $resultado = mysqli_query($conex,$consulta);
	    if ($resultado) {
	    	?>
	    	<h3 class="ok">Añadido correctamente</h3>
           <?php
	    } else {
	    	?>
	    	<h3 class="bad">¡Ups ha ocurrido un error!</h3>
           <?php
	    }
    }   else {
	    	?>
	    	<h3 class="bad">¡Por favor complete los campos!</h3>
           <?php
    }
}

?>
