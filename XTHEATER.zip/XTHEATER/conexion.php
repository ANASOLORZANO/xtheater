<?php
$servername = "localhost";
$database = "xtheater";
$username = "root";
$password= "";

$conexion = mysqli_connect($servername,$username,$password,$database);
?>
