<?php
include("con_db.php");

if (isset($_POST['añadir'])) {
    if ( strlen($_POST['name']) >= 1 && strlen($_POST['app']) >= 1 && strlen($_POST['apm']) >= 1 && strlen($_POST['sex']) >= 1  && strlen($_POST['tel']) >= 1 ) {

      $name = trim($_POST['name']);
	    $app = trim($_POST['app']);
      $apm = trim($_POST['apm']);
      $sex = trim($_POST['sex']);
      $tel = trim($_POST['tel']);



	    $consulta = "INSERT INTO empleado(nombre, apaterno, amaterno, sexo,telefono) VALUES ('$name','$app','$apm','$sex','$tel')";
	    $resultado = mysqli_query($conex,$consulta);
	    if ($resultado) {
	    	?>
	    	<h3 class="ok">Añadido correctamente</h3>
           <?php
	    } else {
	    	?>
	    	<h3 class="bad">¡Ups ha ocurrido un error!</h3>
           <?php
	    }
    }   else {
	    	?>
	    	<h3 class="bad">¡Por favor complete los campos!</h3>
           <?php
    }
}

?>
