-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 04-06-2021 a las 22:40:16
-- Versión del servidor: 10.4.18-MariaDB
-- Versión de PHP: 7.3.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `xtheater`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `asientos`
--

CREATE TABLE `asientos` (
  `asiento` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `asientos`
--

INSERT INTO `asientos` (`asiento`) VALUES
('a1'),
('b1'),
('c1'),
('d1');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `boleto`
--

CREATE TABLE `boleto` (
  `folio` int(10) NOT NULL,
  `funcion` int(10) NOT NULL,
  `idobra` int(10) NOT NULL,
  `idlugar` int(10) NOT NULL,
  `idvendedor` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `boleto`
--

INSERT INTO `boleto` (`folio`, `funcion`, `idobra`, `idlugar`, `idvendedor`) VALUES
(206737, 2, 1, 3, 1),
(249298, 2, 1, 2, 1),
(276735, 2, 1, 4, 1),
(410823, 3, 1, 8, 1),
(546714, 2, 1, 1, 1),
(669781, 3, 1, 7, 1),
(712318, 3, 1, 6, 1),
(831329, 3, 1, 5, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `empleado`
--

CREATE TABLE `empleado` (
  `idempleado` int(11) NOT NULL,
  `nombre` varchar(50) DEFAULT NULL,
  `apaterno` varchar(50) DEFAULT NULL,
  `amaterno` varchar(50) DEFAULT NULL,
  `sexo` varchar(20) DEFAULT NULL,
  `telefono` int(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `empleado`
--

INSERT INTO `empleado` (`idempleado`, `nombre`, `apaterno`, `amaterno`, `sexo`, `telefono`) VALUES
(1, 'Ana', 'Solorzano', 'Lazaro', 'Mujer', 2147483647);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `funcion`
--

CREATE TABLE `funcion` (
  `idfuncion` int(10) NOT NULL,
  `idobra` int(10) NOT NULL,
  `fecha` date NOT NULL,
  `hora` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `funcion`
--

INSERT INTO `funcion` (`idfuncion`, `idobra`, `fecha`, `hora`) VALUES
(2, 1, '2020-04-25', '18:00:00'),
(3, 1, '2020-04-26', '18:00:00'),
(6, 2, '2021-05-30', '14:00:00'),
(7, 13, '2021-06-05', '18:00:00'),
(8, 12, '2021-06-11', '18:00:00');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `lugar`
--

CREATE TABLE `lugar` (
  `idlugar` int(10) NOT NULL,
  `asiento` varchar(5) NOT NULL,
  `idfuncion` int(10) NOT NULL,
  `precio` int(10) NOT NULL,
  `disponible` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `lugar`
--

INSERT INTO `lugar` (`idlugar`, `asiento`, `idfuncion`, `precio`, `disponible`) VALUES
(1, 'a1', 2, 1000, 'NO'),
(2, 'b1', 2, 800, 'NO'),
(3, 'c1', 2, 600, 'NO'),
(4, 'd1', 2, 400, 'NO'),
(5, 'a1', 3, 1000, 'NO'),
(6, 'b1', 3, 800, 'NO'),
(7, 'c1', 3, 600, 'NO'),
(8, 'd1', 3, 400, 'NO');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `lugares`
--

CREATE TABLE `lugares` (
  `ID` int(11) NOT NULL,
  `nombre` varchar(10) DEFAULT NULL,
  `precio` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `lugares`
--

INSERT INTO `lugares` (`ID`, `nombre`, `precio`) VALUES
(1, 'B1', 750),
(2, 'B2', 750),
(3, 'B3', 750),
(4, 'B4', 750),
(5, 'B5', 750),
(6, 'B6', 750),
(7, 'B7', 750),
(8, 'B8', 750),
(9, 'B9', 750),
(10, 'B10', 750),
(11, 'B11', 650),
(12, 'B12', 650),
(13, 'B13', 650),
(14, 'B14', 650),
(15, 'B15', 650),
(16, 'B16', 650),
(17, 'B17', 650),
(18, 'B18', 650),
(19, 'B19', 650),
(20, 'B20', 650),
(21, 'B21', 850),
(22, 'B22', 850),
(23, 'B23', 850),
(24, 'B24', 850),
(25, 'B25', 850),
(26, 'B26', 850),
(27, 'B27', 850),
(28, 'B28', 850),
(29, 'B29', 850),
(30, 'B30', 850);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `obras`
--

CREATE TABLE `obras` (
  `idobra` int(10) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `clasificacion` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `obras`
--

INSERT INTO `obras` (`idobra`, `nombre`, `clasificacion`) VALUES
(1, 'Caperucita Roja', 'A'),
(2, 'Rey León', 'A'),
(12, 'El cascanueces', 'B'),
(13, 'Romeo y Julieta', 'B'),
(14, 'Ricito de oro', 'A');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(10) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `tipo` int(1) NOT NULL,
  `nombre` varchar(255) NOT NULL,
  `apellidos` varchar(255) NOT NULL,
  `fdn` date NOT NULL,
  `direccion` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id`, `email`, `password`, `tipo`, `nombre`, `apellidos`, `fdn`, `direccion`) VALUES
(1, 'user', '1234', 2, 'Ana', 'Solorzano', '1980-04-15', 'Av. 6 Córdoba'),
(2, 'admin', '1234', 1, 'Daniel', 'Ibarra', '1998-08-06', 'Córdoba.');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ventas`
--

CREATE TABLE `ventas` (
  `idventa` int(11) NOT NULL,
  `idfuncion` int(11) DEFAULT NULL,
  `nombre` varchar(50) DEFAULT NULL,
  `precio` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `ventas`
--

INSERT INTO `ventas` (`idventa`, `idfuncion`, `nombre`, `precio`) VALUES
(1, 6, 'B15', 650);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `asientos`
--
ALTER TABLE `asientos`
  ADD PRIMARY KEY (`asiento`);

--
-- Indices de la tabla `boleto`
--
ALTER TABLE `boleto`
  ADD PRIMARY KEY (`folio`),
  ADD KEY `fk_fu` (`idvendedor`),
  ADD KEY `fk_funcion` (`funcion`),
  ADD KEY `fk_lugar` (`idlugar`),
  ADD KEY `fk_obra` (`idobra`);

--
-- Indices de la tabla `empleado`
--
ALTER TABLE `empleado`
  ADD PRIMARY KEY (`idempleado`);

--
-- Indices de la tabla `funcion`
--
ALTER TABLE `funcion`
  ADD PRIMARY KEY (`idfuncion`),
  ADD KEY `funcion_ibfk_1` (`idobra`);

--
-- Indices de la tabla `lugar`
--
ALTER TABLE `lugar`
  ADD PRIMARY KEY (`idlugar`),
  ADD KEY `lugar_ibfk_1` (`asiento`),
  ADD KEY `lugar_ibfk_2` (`idfuncion`);

--
-- Indices de la tabla `lugares`
--
ALTER TABLE `lugares`
  ADD PRIMARY KEY (`ID`);

--
-- Indices de la tabla `obras`
--
ALTER TABLE `obras`
  ADD PRIMARY KEY (`idobra`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `ventas`
--
ALTER TABLE `ventas`
  ADD PRIMARY KEY (`idventa`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `boleto`
--
ALTER TABLE `boleto`
  MODIFY `folio` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=831330;

--
-- AUTO_INCREMENT de la tabla `empleado`
--
ALTER TABLE `empleado`
  MODIFY `idempleado` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `funcion`
--
ALTER TABLE `funcion`
  MODIFY `idfuncion` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT de la tabla `lugar`
--
ALTER TABLE `lugar`
  MODIFY `idlugar` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT de la tabla `obras`
--
ALTER TABLE `obras`
  MODIFY `idobra` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `ventas`
--
ALTER TABLE `ventas`
  MODIFY `idventa` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `boleto`
--
ALTER TABLE `boleto`
  ADD CONSTRAINT `fk_fu` FOREIGN KEY (`idvendedor`) REFERENCES `usuarios` (`id`),
  ADD CONSTRAINT `fk_funcion` FOREIGN KEY (`funcion`) REFERENCES `funcion` (`idfuncion`),
  ADD CONSTRAINT `fk_lugar` FOREIGN KEY (`idlugar`) REFERENCES `lugar` (`idlugar`),
  ADD CONSTRAINT `fk_obra` FOREIGN KEY (`idobra`) REFERENCES `obras` (`idobra`);

--
-- Filtros para la tabla `funcion`
--
ALTER TABLE `funcion`
  ADD CONSTRAINT `funcion_ibfk_1` FOREIGN KEY (`idobra`) REFERENCES `obras` (`idobra`);

--
-- Filtros para la tabla `lugar`
--
ALTER TABLE `lugar`
  ADD CONSTRAINT `lugar_ibfk_1` FOREIGN KEY (`asiento`) REFERENCES `asientos` (`asiento`),
  ADD CONSTRAINT `lugar_ibfk_2` FOREIGN KEY (`idfuncion`) REFERENCES `funcion` (`idfuncion`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
