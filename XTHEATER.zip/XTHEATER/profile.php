<?php
include('session.php');
if($tipo==2){header("location: profile2.php");}
?>
<!DOCTYPE HTML>
<html>
<head>
	<head>

              <meta charset="UTF-8">
              <meta name="viewport" content="width=device-width, initial-scale=1.0">
              <meta http-equiv="X-UA-Compatible" content="ie=edge">
              <link rel="stylesheet" href="home.css">
              <link rel="stylesheet" href="test.css">
              <link rel="icon" type="image/png" href="imagenes/logos/caras.png">


        <title>Inicio</title>
    </head>
</head>
<body>
	<header>
	            <div class="izq">

	                <div class="img">
	                    <img src="imagenes/logos/caras.png" alt="">
	                </div>
	                <div class="title">
	                    <h2>XTHEATER</h2>

	                </div>

	            </div>

	            <div class="der">

	                <div class="switch" id="switch">
	                    <img src="imagenes/logos/luna.png" alt="">
	                </div>

								 									<a href="index.php">
								 										 <div class="boton">
								 												 <img src="imagenes/logos/cerrar.png" alt="">
								 												 <p>Salir</p>
								 										 </div>
								 								 </a>



	                <a href="VerFunciones.php">
	                    <div class="boton">
	                        <img src="imagenes/logos/cartelera.png" alt="">
	                        <p>Funciones</p>
	                    </div>
	                </a>

									<a href="VerObras.php">
											<div class="boton">
													<img src="imagenes/logos/añadir.png" alt="">
													<p>Obras</p>
											</div>
									</a>

									<a href="RegistrarEmpleado.php">
										 <div class="boton">
												 <img src="imagenes/logos/empleado.png" alt="">
												 <p>Empleados</p>
										 </div>
									</a>

	            </div>

	        </header>





<div class="sec1">
					<h1> ¡Bienvenido! </h1>


			</div>

</body>

 <script src="test.js"></script>
</html>
